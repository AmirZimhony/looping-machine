import Header from './components/Header';
import React from 'react';
import MusicBox from './components/MusicBox';
import {Play} from './components/Play';
import audioClips from './components/audioclips';

import  Bass from './music_files/Bass Warwick heavy funk groove on E 120 BPM.mp3';
import  futureFunk from './music_files/120_future_funk_beats_25.mp3';
import  stutterBeats from './music_files/120_stutter_breakbeats_16.mp3';
import  electricGuitar from './music_files/electric guitar coutry slide 120bpm - B.mp3';
import  StompySlosh from './music_files/FUD_120_StompySlosh.mp3';
import  groove from './music_files/GrooveB_120bpm_Tanggu.mp3';
import  MazePolitics from './music_files/MazePolitics_120_Perc.mp3';
import  pas3 from './music_files/PAS3GROOVE1.03B.mp3';
import  organSynth from './music_files/SilentStar_120_Em_OrganSynth.mp3';
import reactDom from 'react-dom';



class App extends React.Component{
  constructor(props) {
    super(props);
    this.playingNow = this.playingNow.bind(this);
    this.finishedPlaying = this.finishedPlaying.bind(this);
    this.startPlaying = this.startPlaying.bind(this);
    this.stopPlaying = this.stopPlaying.bind(this);
    this.state = {counter: 0};
    this.state = {playing : true};
  }

  playingNow() {
    this.setState({counter: this.state.counter + 1});
  }

  finishedPlaying() {
    if (this.state.counter > 0){
      this.setState({counter: this.state.counter - 1});
    }
  }

  startPlaying() {
    this.setState({playing: false})
  }

  stopPlaying() {
    this.setState({playing: true})
  }

  render() {
    const audioClipsss = [
      {sound: Bass, label: 'Funky Bass'},
      {sound: futureFunk, label: 'Future Funk'},
      {sound: stutterBeats, label: 'Stuttering Beats'},
      {sound: electricGuitar, label: 'Electric country guitar'},
      {sound: StompySlosh, label: 'Stompin rythm'},
      {sound: groove, label: 'Groovyyy'},
      {sound: MazePolitics, label: 'The Maze'},
      {sound: pas3, label: 'Sachi drums'},
      {sound: organSynth, label: 'Psychedelic Organ'},
    ]
  


    
    return (
      <div className="container">
        
        <Play on = {this.state.playing} audioClip = {audioClipsss[0]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        <Play on = {this.state.playing} audioClip = {audioClipsss[1]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying} />
        <Play on = {this.state.playing} audioClip = {audioClipsss[2]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        <Play on = {this.state.playing} audioClip = {audioClipsss[3]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        <Play on = {this.state.playing} audioClip = {audioClipsss[4]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        <Play on = {this.state.playing} audioClip = {audioClipsss[5]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        <Play on = {this.state.playing} audioClip = {audioClipsss[6]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        <Play on = {this.state.playing} audioClip = {audioClipsss[7]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        <Play on = {this.state.playing} audioClip = {audioClipsss[8]} playing = {this.startPlaying} stopPlaying = {this.stopPlaying} onPlay = {this.playingNow} offPlay = {this.finishedPlaying}/>
        
      </div>
    );
  }
}


export default App;


